export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'instructor';
  avatar?: string;
  bio?: string;
  joinedDate: string;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  videoUrl?: string;
  pdfUrl?: string;
  duration: number; // in minutes
  order: number;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  shortDescription: string;
  price: number;
  category: string;
  thumbnail: string;
  instructorId: string;
  instructorName: string;
  instructorAvatar?: string;
  lessons: Lesson[];
  duration: number; // total duration in minutes
  enrollmentCount: number;
  rating: number;
  status: 'draft' | 'published';
  createdAt: string;
}

export interface Enrollment {
  id: string;
  userId: string;
  courseId: string;
  enrolledAt: string;
  progress: number; // percentage
  completedLessons: string[];
}

export interface AppContextType {
  user: User | null;
  courses: Course[];
  enrollments: Enrollment[];
  darkMode: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  toggleDarkMode: () => void;
  createCourse: (course: Omit<Course, 'id' | 'instructorId' | 'instructorName' | 'enrollmentCount' | 'rating' | 'createdAt'>) => void;
  updateCourse: (courseId: string, updates: Partial<Course>) => void;
  deleteCourse: (courseId: string) => void;
  enrollInCourse: (courseId: string) => void;
  updateProgress: (courseId: string, lessonId: string) => void;
}