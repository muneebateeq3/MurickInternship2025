import React, { useState } from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { Clock, Users, Star, PlayCircle, FileText, CheckCircle } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { Modal } from '../components/ui/Modal';

export function CourseDetailsPage() {
  const { courseId } = useParams<{ courseId: string }>();
  const { courses, user, enrollments, enrollInCourse } = useApp();
  const [showEnrollModal, setShowEnrollModal] = useState(false);

  if (!courseId) return <Navigate to="/courses" replace />;

  const course = courses.find(c => c.id === courseId);
  if (!course) return <Navigate to="/courses" replace />;

  const isEnrolled = user && enrollments.some(
    e => e.userId === user.id && e.courseId === courseId
  );

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const handleEnroll = () => {
    if (!user) {
      // Redirect to login
      window.location.href = '/login';
      return;
    }

    enrollInCourse(courseId);
    setShowEnrollModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Hero Section */}
      <div className="relative h-96 bg-gradient-to-r from-blue-600 to-purple-700">
        <div className="absolute inset-0">
          <img
            src={course.thumbnail}
            alt={course.title}
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="text-white max-w-3xl">
            <div className="flex items-center space-x-2 mb-4">
              <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm">
                {course.category}
              </span>
              {course.price > 0 ? (
                <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                  ${course.price}
                </span>
              ) : (
                <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                  Free
                </span>
              )}
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              {course.title}
            </h1>
            <p className="text-xl text-blue-100 mb-6">
              {course.description}
            </p>
            <div className="flex items-center space-x-6 text-blue-100">
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>{formatDuration(course.duration)}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5" />
                <span>{course.enrollmentCount} students</span>
              </div>
              {course.rating > 0 && (
                <div className="flex items-center space-x-2">
                  <Star className="w-5 h-5 text-yellow-400 fill-current" />
                  <span>{course.rating}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Instructor Info */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                About the Instructor
              </h2>
              <div className="flex items-start space-x-4">
                {course.instructorAvatar && (
                  <img
                    src={course.instructorAvatar}
                    alt={course.instructorName}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                )}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                    {course.instructorName}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mt-2">
                    Experienced professional with expertise in {course.category.toLowerCase()}
                  </p>
                </div>
              </div>
            </div>

            {/* Course Content */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                Course Content
              </h2>
              <div className="space-y-4">
                {course.lessons.map((lesson, index) => (
                  <div
                    key={lesson.id}
                    className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-8 h-8 bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-2">
                          {lesson.videoUrl ? (
                            <PlayCircle className="w-4 h-4 text-green-500" />
                          ) : (
                            <FileText className="w-4 h-4 text-blue-500" />
                          )}
                          <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                            {lesson.title}
                          </h3>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatDuration(lesson.duration)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {lesson.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Enrollment Card */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              {isEnrolled ? (
                <div className="text-center">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    You're Enrolled!
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Access your course content from the dashboard
                  </p>
                  <button className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-lg font-medium transition-colors">
                    Continue Learning
                  </button>
                </div>
              ) : (
                <div>
                  <div className="text-center mb-6">
                    <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                      {course.price > 0 ? `$${course.price}` : 'Free'}
                    </div>
                    {course.price > 0 && (
                      <p className="text-gray-600 dark:text-gray-400">One-time payment</p>
                    )}
                  </div>
                  <button
                    onClick={handleEnroll}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg font-medium transition-colors mb-4"
                  >
                    {course.price > 0 ? 'Enroll Now' : 'Enroll for Free'}
                  </button>
                  <div className="text-center text-sm text-gray-500 dark:text-gray-400">
                    30-day money-back guarantee
                  </div>
                </div>
              )}
            </div>

            {/* Course Stats */}
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Course Details
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Duration</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {formatDuration(course.duration)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Lessons</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {course.lessons.length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Students</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {course.enrollmentCount}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Category</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {course.category}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Enrollment Success Modal */}
      <Modal
        isOpen={showEnrollModal}
        onClose={() => setShowEnrollModal(false)}
        title="Enrollment Successful!"
      >
        <div className="text-center">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Welcome to the course!
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            You have successfully enrolled in "{course.title}". You can now access all course materials.
          </p>
          <button
            onClick={() => setShowEnrollModal(false)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors"
          >
            Start Learning
          </button>
        </div>
      </Modal>
    </div>
  );
}