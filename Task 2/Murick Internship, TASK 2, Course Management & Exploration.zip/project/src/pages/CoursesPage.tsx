import React, { useState, useMemo } from 'react';
import { CourseCard } from '../components/course/CourseCard';
import { CourseFilters } from '../components/course/CourseFilters';
import { useApp } from '../contexts/AppContext';

export function CoursesPage() {
  const { courses } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedPriceFilter, setSelectedPriceFilter] = useState('');

  const publishedCourses = courses.filter(course => course.status === 'published');

  const categories = useMemo(() => {
    const uniqueCategories = [...new Set(publishedCourses.map(course => course.category))];
    return uniqueCategories.sort();
  }, [publishedCourses]);

  const filteredCourses = useMemo(() => {
    return publishedCourses.filter(course => {
      const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           course.shortDescription.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           course.instructorName.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = !selectedCategory || course.category === selectedCategory;
      
      const matchesPrice = !selectedPriceFilter ||
                          (selectedPriceFilter === 'free' && course.price === 0) ||
                          (selectedPriceFilter === 'paid' && course.price > 0);

      return matchesSearch && matchesCategory && matchesPrice;
    });
  }, [publishedCourses, searchTerm, selectedCategory, selectedPriceFilter]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Explore Courses
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Discover {publishedCourses.length} courses from expert instructors
          </p>
        </div>

        <CourseFilters
          searchTerm={searchTerm}
          selectedCategory={selectedCategory}
          selectedPriceFilter={selectedPriceFilter}
          categories={categories}
          onSearchChange={setSearchTerm}
          onCategoryChange={setSelectedCategory}
          onPriceFilterChange={setSelectedPriceFilter}
        />

        {filteredCourses.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-500 dark:text-gray-400 mb-4">
              <svg className="w-16 h-16 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.47.881-6.08 2.33l-.926-.926C6.64 14.758 9.245 14 12 14s5.36.758 7.006 2.404l-.926.926A7.962 7.962 0 0112 15z" />
              </svg>
              <h3 className="text-lg font-medium mb-2">No courses found</h3>
              <p>Try adjusting your search or filter criteria</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}