import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Course, Enrollment, AppContextType } from '../types';

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock data
const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john@example.com',
    role: 'instructor',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    bio: 'Experienced web developer with 10+ years in the industry',
    joinedDate: '2023-01-15'
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    role: 'student',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    bio: 'Passionate learner interested in technology and design',
    joinedDate: '2023-02-20'
  }
];

const mockCourses: Course[] = [
  {
    id: '1',
    title: 'Complete React Development Course',
    description: 'Master React from basics to advanced concepts including hooks, context, and state management. Build real-world projects and learn industry best practices.',
    shortDescription: 'Learn React from scratch with hands-on projects and real-world examples.',
    price: 99.99,
    category: 'Web Development',
    thumbnail: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
    instructorId: '1',
    instructorName: 'John Doe',
    instructorAvatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    lessons: [
      {
        id: '1',
        title: 'Introduction to React',
        description: 'Understanding React fundamentals and ecosystem',
        videoUrl: 'https://example.com/video1',
        duration: 45,
        order: 1
      },
      {
        id: '2',
        title: 'Components and JSX',
        description: 'Building your first React components',
        videoUrl: 'https://example.com/video2',
        duration: 60,
        order: 2
      }
    ],
    duration: 480,
    enrollmentCount: 156,
    rating: 4.8,
    status: 'published',
    createdAt: '2023-12-01'
  },
  {
    id: '2',
    title: 'JavaScript Fundamentals',
    description: 'Complete guide to JavaScript programming language covering ES6+, async programming, and modern JavaScript features.',
    shortDescription: 'Master JavaScript fundamentals and modern ES6+ features.',
    price: 0,
    category: 'Programming',
    thumbnail: 'https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
    instructorId: '1',
    instructorName: 'John Doe',
    instructorAvatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
    lessons: [
      {
        id: '3',
        title: 'Variables and Data Types',
        description: 'Understanding JavaScript basics',
        videoUrl: 'https://example.com/video3',
        duration: 30,
        order: 1
      }
    ],
    duration: 360,
    enrollmentCount: 289,
    rating: 4.6,
    status: 'published',
    createdAt: '2023-11-15'
  }
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    // Load data from localStorage
    const savedUser = localStorage.getItem('user');
    const savedCourses = localStorage.getItem('courses');
    const savedEnrollments = localStorage.getItem('enrollments');
    const savedDarkMode = localStorage.getItem('darkMode');

    if (savedUser) setUser(JSON.parse(savedUser));
    if (savedCourses) setCourses(JSON.parse(savedCourses));
    else setCourses(mockCourses);
    if (savedEnrollments) setEnrollments(JSON.parse(savedEnrollments));
    if (savedDarkMode) setDarkMode(JSON.parse(savedDarkMode));
    else {
      // Check system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setDarkMode(prefersDark);
    }
  }, []);

  useEffect(() => {
    // Apply dark mode class to document
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Mock login - in real app, this would make API call
    const foundUser = mockUsers.find(u => u.email === email);
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('user', JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const toggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem('darkMode', JSON.stringify(newDarkMode));
  };

  const createCourse = (courseData: Omit<Course, 'id' | 'instructorId' | 'instructorName' | 'enrollmentCount' | 'rating' | 'createdAt'>) => {
    if (!user) return;

    const newCourse: Course = {
      ...courseData,
      id: Date.now().toString(),
      instructorId: user.id,
      instructorName: user.name,
      instructorAvatar: user.avatar,
      enrollmentCount: 0,
      rating: 0,
      createdAt: new Date().toISOString()
    };

    const updatedCourses = [...courses, newCourse];
    setCourses(updatedCourses);
    localStorage.setItem('courses', JSON.stringify(updatedCourses));
  };

  const updateCourse = (courseId: string, updates: Partial<Course>) => {
    const updatedCourses = courses.map(course =>
      course.id === courseId ? { ...course, ...updates } : course
    );
    setCourses(updatedCourses);
    localStorage.setItem('courses', JSON.stringify(updatedCourses));
  };

  const deleteCourse = (courseId: string) => {
    const updatedCourses = courses.filter(course => course.id !== courseId);
    setCourses(updatedCourses);
    localStorage.setItem('courses', JSON.stringify(updatedCourses));
  };

  const enrollInCourse = (courseId: string) => {
    if (!user) return;

    const newEnrollment: Enrollment = {
      id: Date.now().toString(),
      userId: user.id,
      courseId,
      enrolledAt: new Date().toISOString(),
      progress: 0,
      completedLessons: []
    };

    const updatedEnrollments = [...enrollments, newEnrollment];
    setEnrollments(updatedEnrollments);
    localStorage.setItem('enrollments', JSON.stringify(updatedEnrollments));

    // Update course enrollment count
    updateCourse(courseId, {
      enrollmentCount: courses.find(c => c.id === courseId)?.enrollmentCount + 1 || 1
    });
  };

  const updateProgress = (courseId: string, lessonId: string) => {
    if (!user) return;

    const updatedEnrollments = enrollments.map(enrollment => {
      if (enrollment.courseId === courseId && enrollment.userId === user.id) {
        const completedLessons = [...enrollment.completedLessons];
        if (!completedLessons.includes(lessonId)) {
          completedLessons.push(lessonId);
        }

        const course = courses.find(c => c.id === courseId);
        const progress = course ? (completedLessons.length / course.lessons.length) * 100 : 0;

        return {
          ...enrollment,
          completedLessons,
          progress: Math.round(progress)
        };
      }
      return enrollment;
    });

    setEnrollments(updatedEnrollments);
    localStorage.setItem('enrollments', JSON.stringify(updatedEnrollments));
  };

  return (
    <AppContext.Provider value={{
      user,
      courses,
      enrollments,
      darkMode,
      login,
      logout,
      toggleDarkMode,
      createCourse,
      updateCourse,
      deleteCourse,
      enrollInCourse,
      updateProgress
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}